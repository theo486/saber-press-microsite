SABER — PRESS & BRAND ASSET PACK
Logo: saber-logo.svg (primary) · logo-white.png (for dark backgrounds)
Product imagery: product-ui.png + dashboard / workspace screenshots
Brand: font PP Mori (Inter fallback) · core #1C2429 / #F0EEED · primary #896FF6 · accent #F68722
Please don't alter or recolour the logo. Press contact: press@sabermine.ai
